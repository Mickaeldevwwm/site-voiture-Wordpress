<form role="search" name="search" class="searchform" action="http://localhost:8888/voitesdeluxe" method="get">
  <div class="formulaire">
    <input type="text" name="s" class="search" placeholder="Rechercher" value="<?php the_search_query(); ?>" />
    <input type="submit" alt="Search"/>
      </div>
</form>
