<?php get_header(); ?>

<?php if( have_posts() ) : while( have_posts() ) : the_post(); ?>

    <h2><?php the_title(); ?></h2>
        <?php the_content(); ?>
        <div class="taxo">
          <?php the_terms( get_the_ID() , 'Constructeurs' ); ?>
          <br>
          <?php the_terms( get_the_ID() , 'annee' ); ?>
            <?php the_field( 'citation' ); ?>
        </div>

        <?php
          $picture_ID = get_field( 'avatar' ); // On récupère cette fois l'ID
          $url = wp_get_attachment_image_src( $picture_ID, 'post-thumbnail' );
        ?>
          <img src="<?php echo $url[0]; ?>">
        <?php
        	$picture_ID = get_field( 'photo' ); // On récupère cette fois l'ID
        	$url = wp_get_attachment_image_src( $picture_ID, 'post-thumbnail' );
        ?>
        	<img src="<?php echo $url[0]; ?>">

<?php endwhile; endif; ?>


<?php get_footer(); ?>
