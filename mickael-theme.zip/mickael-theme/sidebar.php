<?php get_header(); ?>
        <aside class="site__sidebar">
        	<ul>
            	<?php dynamic_sidebar( 'blog-sidebar' ); ?>
            </ul>
        </aside>
	</div>
<?php get_footer(); ?>
