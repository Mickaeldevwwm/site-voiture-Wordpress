<?php get_header(); ?>
<h1 style="color: white; text-align: center">hello 404</h1>
<?php get_footer(); ?>
