<?php

// Ajouter la prise en charge des images en mises en avant
add_theme_support('post-thumbnails');

// Ajouter automatiquement le titre du site dans l'en-tete du site
// add_theme_support('title-tag');


register_nav_menus( array(
	'main' => 'Menu Principal',
	'footer' => 'Bas de page',
) );

function add_theme_stylesheet() {
  wp_enqueue_style( 'style', get_stylesheet_uri() );
    }
add_action( 'wp_enqueue_scripts', 'add_theme_stylesheet' );


register_sidebar( array(
	'id' => 'blog-sidebar',
	'name' => 'Blog',
) );

function constructeur_register_post_types() {

        $labels = array(
        'name' => 'constructeur',
        'all_items' => 'Tous les constructeurs',  // affiché dans le sous menu
        'singular_name' => 'Projet',
        'add_new_item' => 'Ajouter',
        'edit_item' => 'Modifier',
        'menu_name' => 'constructeur'
    );

	$args = array(
        'labels' => $labels,
        'public' => true,
        'show_in_rest' => true,
        'has_archive' => true,
        'supports' => array( 'title', 'editor','thumbnail' ),
        'menu_position' => 5,
        'menu_icon' => 'dashicons-admin-customizer',
	);

	register_post_type( 'constructeur', $args );
}
add_action( 'init', 'constructeur_register_post_types' );


function modele_register_post_types() {

  $labels = array(
        'name' => 'modeles',
        'all_items' => 'Tous les modeles',  // affiché dans le sous menu
        'singular_name' => 'Projet',
        'add_new_item' => 'Ajouter',
        'edit_item' => 'Modifier',
        'menu_name' => 'modeles'
    );

	$args = array(
        'labels' => $labels,
        'public' => true,
        'show_in_rest' => true,
        'has_archive' => true,
        'supports' => array( 'title', 'editor','thumbnail' ),
        'menu_position' => 6,
        'menu_icon' => 'dashicons-admin-customizer',
	);

	register_post_type( 'modeles', $args );

     // Déclaration de la Taxonomie
     $labelstaxo = array(
      'name' => 'Constructeurs',
      'new_item_name' => 'Nom du nouveau Projet',
     	'parent_item' => 'Type de projet parent',
     );

     $argstaxo = array(
         'labels' => $labelstaxo,
         'public' => true,
         'show_in_rest' => true,
         'hierarchical' => true
     );

    register_taxonomy( 'Constructeurs', 'modeles', $argstaxo );

 	$taglabels = array(
 		'name'                       => __( 'annees', 'Taxonomy General Name', 'text_domain' ),
 		'singular_name'              => __( 'annee', 'Taxonomy Singular Name', 'text_domain' ),
 		'menu_name'                  => __( 'Années', 'text_domain' ),
 		'all_items'                  => __( 'Toutes les annees', 'text_domain' ),
 		'parent_item'                => __( 'Parent Item', 'text_domain' ),
 		'parent_item_colon'          => __( 'Parent Item:', 'text_domain' ),
 		'new_item_name'              => __( 'Nom de la nouvelle année', 'text_domain' ),
 		'add_new_item'               => __( 'Ajouter une nouvelle année', 'text_domain' ),
 		'edit_item'                  => __( 'Editer une année', 'text_domain' ),
 		'update_item'                => __( 'Mettre à jour une année', 'text_domain' ),
 		'view_item'                  => __( 'Voir une année', 'text_domain' ),
 		'separate_items_with_commas' => __( 'séparer les années avec des virgules', 'text_domain' ),
 		'add_or_remove_items'        => __( 'Aujouter ou supprimer une année', 'text_domain' ),
 		'choose_from_most_used'      => __( 'Choose from the most used', 'text_domain' ),
 		'popular_items'              => __( 'Années Populaire', 'text_domain' ),
 		'search_items'               => __( 'Rechercher des années', 'text_domain' ),
 		'not_found'                  => __( 'Inconnue', 'text_domain' ),
 		'no_terms'                   => __( 'Aucune année', 'text_domain' ),
 		'items_list'                 => __( 'Liste d\'année', 'text_domain' ),
 		'items_list_navigation'      => __( 'Navigation par liste d\'années', 'text_domain' ),
 	);
 	$tagargs = array(
 		'labels'                     => $taglabels,
 		'hierarchical'               => false,
 		'public'                     => true,
 		'show_ui'                    => true,
 		'show_admin_column'          => true,
		'show_in_rest' 							 => true,
 		'show_in_nav_menus'          => true,
 		'show_tagcloud'              => true,
 	);
 	register_taxonomy( 'annee', 'modeles', $tagargs );

 }

add_action( 'init', 'modele_register_post_types' ); // Le hook init lance la fonction
